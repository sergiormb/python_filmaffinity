*******
python_filmaffinity
*******

|version| |travis| |coveralls| |license|


Installation
============

Using ``pip``:


::

	pip install python_filmaffinity


.. |travis| image:: http://img.shields.io/travis/sergiormb/python_filmaffinity/master.svg?style=flat-square
    :target: https://travis-ci.org/sergiormb/python_filmaffinity

.. |coveralls| image:: http://img.shields.io/coveralls/sergiormb/python_filmaffinity/master.svg?style=flat-square
    :target: https://coveralls.io/r/sergiormb/python_filmaffinity

.. |license| image:: http://img.shields.io/pypi/l/python_filmaffinity?style=flat-square
    :target: https://pypi.python.org/pypi/python_filmaffinity
