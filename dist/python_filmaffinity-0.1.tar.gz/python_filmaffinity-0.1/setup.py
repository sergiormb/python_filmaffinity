from setuptools import setup, find_packages

setup(
    name='python_filmaffinity',
    version='0.1',
    # this must be the same as the name above
    packages=find_packages(exclude=["*.tests", "*.tests.*", "tests.*",
                                    "tests", "*tests*"]),
    description='Search for movies in Filmaffinity',
    author='sergiormb',
    license='MIT',
    author_email='sergiormb88@gmail.com',
    install_requires=[
        'requests>=2.5.0',
        'bs4>=0.0.1'
    ],
    zip_safe=False,
    # use the URL to the github repo
    url='https://github.com/sergiormb/python_filmaffinity',
    download_url='https://github.com/sergiormb/python_filmaffinity/tarball/0.1',
    keywords=['filmaffinity', 'movies', 'films'],
    classifiers=[
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4'
    ]
)
